import { Component} from '@angular/core';
import {NavController,IonicPage,NavParams,ModalController,Platform,PopoverController,AlertController} from 'ionic-angular';
import {Storage} from '@ionic/storage';
import { RestProvider} from '../../providers/rest/rest';
import {StorageProvider} from '../../providers/storage/storage';
import {SampleModalPage} from '../sample-modal/sample-modal';
import { CommandSucceedPage} from '../command-succeed/command-succeed';
import { MescmdPage } from '../mescmd/mescmd';
import { PopoverPage } from '../popover/popover';
import { InscriptionPage } from '../inscription/inscription';


@IonicPage()
@Component({
  selector: 'page-commande',
  templateUrl: 'commande.html',
})
export class CommandePage {
	
	arrayPanier= new Array();
	produits= new Array();
	login:any;
	prixTotal:number;
	nombreTotal:number;
	baseUrl = 'https://node16375-ounkoun1.hidora.com/backend/web/app_dev.php/';
	isLoading:boolean=true;
	hasConfirmAdress:boolean =false;
	hasConfirmLivraisonMode:boolean =false;
	hasConfirmCommand:boolean =false;
	hasPaided:boolean =false;
	hasAddress:boolean=true;
	user:any;
	LivraisonType:any="domicile";
	paiementType:any= "livraison";
	adresseLivraison:any;
	tab:any= "tab1";
	today = new Date();
	panierSize:number=0;
	favorisSize:number=0;
    creationDate = new Date().toISOString().slice(0,10);
	isConnected:boolean=false;
    livraison={ "type":1,
                "price":700,
                "delais":"2019-09-18"};

    constructor(public navCtrl: NavController,public popoverCtrl: PopoverController,public navParams: NavParams, public restProvider: RestProvider,
    public storageProvider:StorageProvider, public plt: Platform, private storage: Storage,public alertCtrl: AlertController, public modalCtrl: ModalController) {
	   
	  this.restProvider.setView1();
	  this.storage.get('user').then((val) => {
				this.isConnected= (val == null)? false:true;
				if(this.isConnected){
					this.login= val.login;
				}
	  });

	  this.today = new  Date(this.today.getFullYear()+"-"+this.pad(this.today.getMonth()+1)+"-"+this.pad(this.today.getDate()));
	  //add a day to the date
      this.today.setDate(this.today.getDate() + 2);
	 
	  var y = this.today.getFullYear();
      var m = this.today.getMonth() + 1 ; // january is month 0 in javascript
      var d = this.today.getDate();
	
     var livraisonDate = [y, this.pad(m), this.pad(d)].join("-");
	 this.livraison.delais= livraisonDate;

	  
	this.restProvider.setView1();
	this.storage.get('user').then((val) => {
		this.user=val;
		this.adresseLivraison= val.adresseLivraison;
		this.login=val.login;
		
		this.hasAddress= val.adresseLivraison==null? false:true;
		
		if(this.adresseLivraison!='null'){
			
		}
		
		this.restProvider.getPanier(this.login).subscribe(
				data => {
					if(data.statut=="200"){	
						this.arrayPanier=data.data.products;
						this.isLoading=false;
						this.prixTotal= this.totalPanier();
						this.nombreTotal= this.totalArticle();
					}

				},
					err => {
						console.log(err);
					},
					() => console.log('Movie Search Complete')
		);   
		  
	  });
	  
	}

	ionViewDidLoad() {
    console.log(' ionViewDidLoad CommandePage');
	}
	
	pad (val) {
		var str = val.toString(); 
		return (str.length < 2) ? "0" + str : str;
	}
	
	 
  
	showAdressModal(){
		 let myModal = this.modalCtrl.create(SampleModalPage);
		myModal.present();
		myModal.onDidDismiss((data) => {
			this.isLoading=true;
			this.storage.get('user').then((val) => {
				this.adresseLivraison= val.adresseLivraison;
				this.hasAddress= val.adresseLivraison==null? false:true;
				this.login=val.login;
				this.isLoading=false;
			});
		});
	}

	totalPanier(){
		var total=0;
		for(var i=0;i<this.arrayPanier.length;i++){
			if(this.arrayPanier[i].number <= this.arrayPanier[i].product.quantity){
				if(this.arrayPanier[i].product.retailSale.isInPromotion){
					total+= this.arrayPanier[i].number *  this.arrayPanier[i].product.retailSale.promotionalPrice;
					this.produits.push({'name':this.arrayPanier[i].product.name,'quantity':this.arrayPanier[i].number,'price':this.arrayPanier[i].product.retailSale.promotionalPrice});

				}
				else{
					total+= this.arrayPanier[i].number *  this.arrayPanier[i].product.retailSale.price;
					this.produits.push({'name':this.arrayPanier[i].product.name,'quantity':this.arrayPanier[i].number,'price':this.arrayPanier[i].product.retailSale.price});

				}
			} 
		} 
		return total;
	}
	
	totalArticle(){
		var total=0;
		for(var i=0;i<this.arrayPanier.length;i++){
			if(this.arrayPanier[i].number <= this.arrayPanier[i].product.quantity){
				total++;
			} 
		} 
		return total;
	}
	
	 
	objecttoParams(obj) {
		var p = [];
		for (var key in obj) {
		p.push(key + '=' + encodeURIComponent(obj[key]));
		}
		return p.join('&');
	} 
	
	sendCommand(){
		
		this.isLoading=true;
		var myobject = {login:this.login,commandDate: this.creationDate, adressL:JSON.stringify(this.adresseLivraison),livraison:JSON.stringify(this.livraison),products:JSON.stringify(this.produits)};
		this.restProvider.postCommand(this.objecttoParams(myobject)).subscribe(
				data => {
					if(data.statut=="200"){	
						this.navCtrl.pop();
						this.navCtrl.push(CommandSucceedPage);
						this.storage.remove('panier');
						this.isLoading=false;
					}
				},
					err => {
						console.log(err);
					},
					() => console.log('Movie Search Complete')
	    ); 
    }
	
	disconnect(){  
	  let alert = this.alertCtrl.create();
      alert.setTitle('Confirmation de la deconnexion');
	  alert.setMessage("Voulez-vous vous deconnecter ?");
      alert.addButton('Non');
	
	  alert.addButton({
		text: 'Oui',
		handler: data => {
			this.storage.remove('user');
			this.storage.remove('favoris');
			this.storage.remove('panier');
			this.panierSize=0;
			this.arrayPanier=[];
			this.favorisSize=0;
			this.isConnected=false;
			this.navCtrl.popToRoot();
			this.restProvider.setView1();
		}
	  });

     alert.present();  
  }
  
  
  presentPopover(event){ 
	let data = {isConnected:true}
	let popover = this.popoverCtrl.create(PopoverPage,{data});
	popover.present({ ev: event }); 
	
	popover.onDidDismiss(data => {
      if(data!=null){
		  
		  if(data=="1"){
		    this.disconnect();   
		  }
		  else if(data=="2"){
			this.tab="tab2" ;   
		  }
		  else if(data=="3"){
			this.navCtrl.popToRoot();
			this.restProvider.setView2();    
		  }
		  
		  else if(data=="4"){
			this.navCtrl.push(MescmdPage);    
		  }
         
      }
    })
  }
	
	
    

  

}
