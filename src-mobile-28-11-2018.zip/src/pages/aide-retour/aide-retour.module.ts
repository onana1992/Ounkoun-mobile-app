import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AideRetourPage } from './aide-retour';

@NgModule({
  declarations: [
   // AideRetourPage,
  ],
  imports: [
   // IonicPageModule.forChild(AideRetourPage),
  ],
})
export class AideRetourPageModule {}
