import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AidePaiementPage } from './aide-paiement';

@NgModule({
  declarations: [
   // AidePaiementPage,
  ],
  imports: [
    //IonicPageModule.forChild(AidePaiementPage),
  ],
})
export class AidePaiementPageModule {}
