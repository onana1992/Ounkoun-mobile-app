import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AideLivraisonPage } from './aide-livraison';

@NgModule({
  declarations: [
  //  AideLivraisonPage,
  ],
  imports: [
   // IonicPageModule.forChild(AideLivraisonPage),
  ],
})
export class AideLivraisonPageModule {}
