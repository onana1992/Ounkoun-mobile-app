import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MescmdPage } from './mescmd';

@NgModule({
  declarations: [
  //  MescmdPage,
  ],
  imports: [
    IonicPageModule.forChild(MescmdPage),
  ],
})
export class MescmdPageModule {}
