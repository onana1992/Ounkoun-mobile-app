import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FiltreModalRecherchePage } from './filtre-modal-recherche';

@NgModule({
  declarations: [
   // FiltreModalRecherchePage,
  ],
  imports: [
   // IonicPageModule.forChild(FiltreModalRecherchePage),
  ],
})
export class FiltreModalRecherchePageModule {}
