import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CommandModalPage } from './command-modal';

@NgModule({
  declarations: [
  //  CommandModalPage,
  ],
  imports: [
    IonicPageModule.forChild(CommandModalPage),
  ],
})
export class CommandModalPageModule {}
