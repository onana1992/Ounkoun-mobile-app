import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SousCategoriePage } from './sous-categorie';

@NgModule({
  declarations: [
   // SousCategoriePage,
  ],
  imports: [
    IonicPageModule.forChild(SousCategoriePage),
  ],
})
export class SousCategoriePageModule {}
