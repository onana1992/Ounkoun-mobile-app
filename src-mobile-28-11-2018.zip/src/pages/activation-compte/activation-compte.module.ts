import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ActivationComptePage } from './activation-compte';

@NgModule({
  declarations: [
	// ActivationComptePage
  ],
  imports: [
    IonicPageModule.forChild(ActivationComptePage),
  ],
})
export class ActivationComptePageModule {}
