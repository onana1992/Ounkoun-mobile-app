import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProduitParVendeurPage } from './produit-par-vendeur';

@NgModule({
  declarations: [
 //   ProduitParVendeurPage,
  ],
  imports: [
  //  IonicPageModule.forChild(ProduitParVendeurPage),
  ],
})
export class ProduitParVendeurPageModule {}
