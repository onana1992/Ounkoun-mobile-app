import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage} from '@ionic/storage';
import { RestProvider} from '../../providers/rest/rest';



@IonicPage()
@Component({
  selector: 'page-command-succeed',
  templateUrl: 'command-succeed.html',
})


 export class CommandSucceedPage {
	 
	 nom:any; 
	 prenom:any;

	constructor(public navCtrl: NavController,public navParams: NavParams,private storage: Storage,public restProvider: RestProvider) {
	  
	  this.restProvider.setView1();
	  this.storage.get('user').then((val) =>{
		this.nom=val.name;
        this.prenom=val.name;		
	  });
	  
	}

	ionViewDidLoad() {
		console.log('ionViewDidLoad CommandSucceedPage');
	}
	
	gotTheRoot(){
		this.navCtrl.popToRoot();
	}
	
 }
