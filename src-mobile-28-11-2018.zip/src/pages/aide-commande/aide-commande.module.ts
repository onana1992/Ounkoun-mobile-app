import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
//import { AideCommandePage } from './aide-commande';

@NgModule({
  declarations: [
   // AideCommandePage,
  ],
  imports: [
   // IonicPageModule.forChild(AideCommandePage),
  ],
})
export class AideCommandePageModule {}
