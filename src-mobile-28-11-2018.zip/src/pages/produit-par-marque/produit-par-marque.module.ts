import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProduitParMarquePage } from './produit-par-marque';

@NgModule({
  declarations: [
   // ProduitParMarquePage,
  ],
  imports: [
    IonicPageModule.forChild(ProduitParMarquePage),
  ],
})
export class ProduitParMarquePageModule {}
