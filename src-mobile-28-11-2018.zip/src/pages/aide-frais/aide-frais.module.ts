import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
//import { AideFraisPage } from './aide-frais';

@NgModule({
  declarations: [
    //AideFraisPage,
  ],
  imports: [
   // IonicPageModule.forChild(AideFraisPage),
  ],
})
export class AideFraisPageModule {}
