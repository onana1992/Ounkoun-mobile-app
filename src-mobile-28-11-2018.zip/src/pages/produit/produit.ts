import { Component} from '@angular/core';
import { IonicPage, NavController, PopoverController, NavParams,ModalController,AlertController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
//import {HomePage} from '../home/home';
import { Storage} from '@ionic/storage';
import { FavorisPage} from '../favoris/favoris';
import { RecherchePage} from '../recherche/recherche';
import {PanierBwmPage} from '../panier-bwm/panier-bwm';
import {RatingModalPage} from '../rating-modal/rating-modal';
import {ProduitParVendeurPage} from '../produit-par-vendeur/produit-par-vendeur';
import { PopoverPage } from '../popover/popover';
import { MescmdPage } from '../mescmd/mescmd';
import { InscriptionPage } from '../inscription/inscription';



@IonicPage()
@Component({
  selector: 'page-produit',
  templateUrl: 'produit.html',
})
export class ProduitPage { 
  tab:any = "tab1";
  isLoading = true;
  produitName:any;
  produit:any;
  product:any;
  name:any;
  selectedProduit:any;
  panierSize:number=0;
  arrayPanier= new Array();
  panierBWMSize:number=0;
  favorisSize:number=0;
  isConnected:boolean=false;
  baseUrl = 'https://node16375-ounkoun1.hidora.com/backend/web/app_dev.php/';
  arraySize=new Array();
  favoryArray= new Array();
  panierArray= new Array();
  panierBWMArray= new Array();
  localFavoryArray= new Array();
  showMessageAjoutFavori:boolean=false;
  showMessageAjoutPanier:boolean=false;
  showMessageAjoutBWMPanier:boolean=false;
  favorisData={login:"",idProduct:""};
  panierData={login:"",idProduct:"",type:"detail",number:1};
  panierBWMData={login:"",idProduct:"",type:"BWM",number:1};
  login="";
  
  constructor(public navCtrl: NavController, public navParams: NavParams,private restProvider: RestProvider,
   public modalCtrl : ModalController,public alertCtrl: AlertController,private storage: Storage,public popoverCtrl: PopoverController) {
	  
	this.produitName = navParams.get('ProduitName'); 
	this.restProvider.setView1();
	this.storage.get('user').then((val) => {
			this.isConnected= (val == undefined)? false:true;
			if(this.isConnected){
				this.login= val.login;
			}
	});
	
	this.storage.get('panier').then((val) => {	
		if(val!= undefined ){
			this.panierSize=0;
			for(var i=0;i<val.length;i++){
				this.panierSize+= val[i].number;
			}
		}
	});	
	
	this.storage.get('panierBWM').then((val) => {		
		if(val!= undefined ){
			this.panierBWMSize=0;
			for(var i=0;i<val.length;i++){
				this.panierBWMSize+= val[i].number;
			}
		}
	});	
	
	this.storage.get('favoris').then((val) => {	
		if(val!= undefined ){
			this.favorisSize= val.length;

		}
	});	

	this.restProvider.getProduit(this.produitName ).subscribe(
        data => {
			//this.response = data.data;
			this.produit = data.data.product;
			this.isLoading = false;
            for( var i=0;i< this.produit.quantity;i++){
				this.arraySize[i] = i+1;
				this.produit.number=1;
			}
        },
        err => {
            console.log(err);
        },
        () => console.log('Complete')
	);
  }
	
  ionViewDidLoad() {
    console.log('ionViewDidLoad ProduitPage');
  }
  
  objecttoParams(obj) {
		var p = [];
		for (var key in obj) {
		p.push(key + '=' + encodeURIComponent(obj[key]));
		}
		return p.join('&');
  }
  
  addPanier(produit:any){ 
	var number=0;
	this.storage.get('panier').then((val) => {
		
		if(val!=null){
			this.panierArray=val;	
		}
		
		 
		for(var i=0;i< this.panierArray.length;i++){
			if(this.panierArray[i].productId == produit.id && this.panierArray[i].type=="detail" ){
			 number= this.panierArray[i].number;
			 this.panierArray.splice(i,1);
			}	
		} 
		
		if(number+1<=produit.quantity){
			this.showMessageAjoutPanier=true;
			this.panierArray.push({productId:produit.id,name:produit.name, number: number + parseInt(produit.number), type:"detail", product:produit});
			this.storage.set("panier",this.panierArray);
			this.panierSize += parseInt(produit.number);
			
			setTimeout(() => {
					this.showMessageAjoutPanier=false;
			}, 2000);
			if(this.isConnected){
				this.panierData.login= this.login;
				this.panierData.idProduct= produit.id;
				this.panierData.number = produit.number;
				this.restProvider.postPanier(this.objecttoParams(this.panierData)).subscribe(
						data => {
							
						},
						err => {
							console.log(err);
						},
				() => console.log('Complete'));
			}
		}
		else{
			
		} 
	});  
  }
  
  
  addPanierBWM(produit:any){ 
	var number=0;
	this.storage.get('panierBWM').then((val) => {
		
		if(val!=null){
			this.panierBWMArray=val;	
		}
		
		 
		for(var i=0;i< this.panierBWMArray.length;i++){
			if(this.panierBWMArray[i].productId == produit.id && this.panierBWMArray[i].type=="BWM" ){
			 number= this.panierBWMArray[i].number;
			 this.panierBWMArray.splice(i,1);
			}	
		} 
		
		if(number+1<=produit.quantity){
			this.showMessageAjoutBWMPanier=true;
			this.panierBWMArray.push({productId:produit.id,name:produit.name, number: number + parseInt(produit.number), type:"BWM", product:produit});
			this.storage.set("panierBWM",this.panierBWMArray);
			this.panierBWMSize += parseInt(produit.number);
			
			setTimeout(() => {
					this.showMessageAjoutBWMPanier=false;
			}, 2000);
			if(this.isConnected){
				this.panierBWMData.login= this.login;
				this.panierBWMData.idProduct= produit.id;
				this.panierBWMData.number = produit.number;
				this.restProvider.postPanierBWM(this.objecttoParams(this.panierBWMData)).subscribe(
						data => {
							
						},
						err => {
							console.log(err);
						},
				() => console.log('Complete'));
			}
		}
		else{
			
		} 
	});  
  }
  
  addFavorite(produit:any){
	if(this.isConnected){
		 this.storage.get('favoris').then((val) => {
			if(val!=null){
				this.localFavoryArray= val;
				for(var i=0; i< val.length;i++){
					if(produit.name == val[i].name){
						return;
					}
				}
				this.localFavoryArray.push({name:produit.name});
				this.storage.set("favoris",this.localFavoryArray);
				this.showMessageAjoutFavori=true;
				this.favorisSize +=1;
				setTimeout(() => {
					this.showMessageAjoutFavori=false;
				}, 2000);
				this.favorisData.login= this.login;
				this.favorisData.idProduct= produit.id;
				this.restProvider.postFavori(this.objecttoParams(this.favorisData)).subscribe(
					data => {
					},
					err => {
						console.log(err);
					},
				() => console.log('Complete'));
			
			}else{
				this.localFavoryArray.push({name:produit});
				this.storage.set("favoris",this.localFavoryArray);
				this.favorisSize+=1;
			}
				
		});
	}
	else{
		alert("pas connecter");
	}
	
  }
  
  
  changeTab(tab){
	  if (tab === "tab1") {
		this.tab= "tab1"
	} 
	else if (tab === 'tab2') {
		this.tab="tab2";
	}
	
	else if (tab === "tab3") {
		this.tab="tab3";
	}
  }
  
   openPanier(){ 
	this.navCtrl.popToRoot();
	this.restProvider.setView3();
   }
   
  
  openPanierBWM(){
	this.navCtrl.push(PanierBwmPage);  
  }
  
  
  openFavoris(){
	this.navCtrl.push(FavorisPage);  
  }
  
  goTorecheche(){
	this.navCtrl.push(RecherchePage);
  }


  openVendeur(vendeur){
	this.navCtrl.push(ProduitParVendeurPage, {seller:vendeur.nom});  
  }
 
  showRatingModal(){

	let myModal = this.modalCtrl.create(RatingModalPage,{produit: this.produitName });
	myModal.present();

	myModal.onDidDismiss((data) => {

		this.isLoading = true;
		this.restProvider.getProduit(this.produitName ).subscribe(
        	data => {
			this.produit = data.data.product;
			this.isLoading = false;
        },
        err => {
            console.log(err);
        },
        () => console.log('Complete')
	);
				
			});
  }

  disconnect(){  
	  let alert = this.alertCtrl.create();
      alert.setTitle('Confirmation de la deconnexion');
	  alert.setMessage(" voulez-vous deconnecter");
      alert.addButton('Non');
	
	  alert.addButton({
		text: 'Oui',
		handler: data => {
			this.storage.remove('user');
			this.storage.remove('favoris');
			this.storage.remove('panier');
			this.panierSize=0;
			this.arrayPanier=[];
			this.favorisSize=0;
			this.isConnected=false;
			this.navCtrl.popToRoot();
			this.restProvider.setView1();
		}
	  });

      alert.present();  
    }


   presentPopover(event){ 
		
	let data = {isConnected:this.isConnected}
	let popover = this.popoverCtrl.create(PopoverPage,{data});
	popover.present({ ev: event }); 
	
	popover.onDidDismiss(data => {
      if(data!=null){
		  
		  if(data=="1"){
		    this.disconnect();   
		  }
		  else if(data=="2"){
			this.tab="tab2" ;   
		  }
		  else if(data=="3"){
			this.navCtrl.popToRoot();
			this.restProvider.setView2();   
		  }
		  
		  else if(data=="4"){
			this.navCtrl.push(MescmdPage);    
		  }
         
      }
    })
  }


}
