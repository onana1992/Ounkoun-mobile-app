import { Component, ViewChild } from '@angular/core';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Nav, Platform ,IonicApp} from 'ionic-angular';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { FavorisPage } from '../pages/favoris/favoris';
import { RestProvider } from '../providers/rest/rest';
import { CategoriePage } from '../pages/categorie/categorie';
import { SousCategoriePage } from '../pages/sous-categorie/sous-categorie';
import { SousSCategoriePage } from '../pages/sous-s-categorie/sous-s-categorie';



@Component({
  templateUrl: 'app.html'
})
export class MyApp {
	
  @ViewChild(Nav) nav: Nav;
  rootPage: any = HomePage;
  pages: Array<{title: string, component: any}>;
  showLevel1 = null;
  showLevel2 = null;
  categories:any;
 
  // pages: any;
  toggleLevel1(idx) {
	if (this.isLevel1Shown(idx)) {
		this.showLevel1 = null;
	} else {
		this.showLevel1 = idx;
	}
  };

  toggleLevel2(idx) {
	if (this.isLevel2Shown(idx)) {
		this.showLevel2 = null;
	} else {
		this.showLevel2 = idx;
	}
  };

  isLevel1Shown(idx) {
  return this.showLevel1 === idx;
 };

 isLevel2Shown(idx) {
  return this.showLevel2 === idx;
 };
 
  response:any;
  
  backButtonListener(): void {
    window.onpopstate = (evt) => {
      // Close any active modals or overlays
      let activePortal = this.ionicApp._loadingPortal.getActive() ||
        this.ionicApp._modalPortal.getActive() ||
        this.ionicApp._toastPortal.getActive() ||
        this.ionicApp._overlayPortal.getActive();
      if (activePortal) {
        activePortal.dismiss();
        return;
      }
    }
  }
  constructor(public platform: Platform, private restProvider: RestProvider,private ionicApp: IonicApp, private splashScreen:SplashScreen) {
    this.initializeApp();
	

    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'Home', component: HomePage },
      { title: 'List', component: ListPage }
    ];
	
	 this.backButtonListener();
	
	this.restProvider.getCategories().subscribe(
        data => {
            this.categories = data.data;
            console.log(data);
        },
        err => {
            console.log(err);
        },
        () => console.log('Complete')
    );

  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      //this.statusBar.styleDefault();
     // this.splashScreen.hide();
    }); 
  }

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }
  
  openCategorie(cat){
	this.nav.push(CategoriePage, { nomCategorie :cat });  
  }
  
  openHome(){
	this.nav.push(HomePage);  
  }
  
  openMonCompte(){
	this.nav.push(HomePage, { page :"tab2" });  
  }
  
  openMonPanier(){
	this.nav.push(HomePage, { page :"tab3" });  
  }
  
  openMesFavoris(){
	this.nav.push(FavorisPage);  
  }
  
  openSousCategorie(cat,sCat){
	this.nav.push(SousCategoriePage, {nomCategorie :cat,nomSousCategorie :sCat});  
  }
  
  openSSousCategorie(ssCat){
	this.nav.push(SousSCategoriePage, { nomSousCategorie :ssCat });  
  }
  
  

}
