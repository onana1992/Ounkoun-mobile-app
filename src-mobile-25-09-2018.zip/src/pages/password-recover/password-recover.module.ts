import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PasswordRecoverPage } from './password-recover';

@NgModule({
  declarations: [
   // PasswordRecoverPage,
  ],
  imports: [
   // IonicPageModule.forChild(PasswordRecoverPage),
  ],
})
export class PasswordRecoverPageModule {}
