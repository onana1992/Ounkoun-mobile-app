import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FiltreModalCatPage } from './filtre-modal-cat';

@NgModule({
  declarations: [
    //FiltreModalCatPage,
  ],
  imports: [
    //IonicPageModule.forChild(FiltreModalCatPage),
  ],
})
export class FiltreModalCatPageModule {
	
	
}
