import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CommandePage } from './commande';

@NgModule({
  declarations: [
  //  CommandePage,
  ],
  imports: [
    IonicPageModule.forChild(CommandePage),
  ],
})
export class CommandePageModule {}
