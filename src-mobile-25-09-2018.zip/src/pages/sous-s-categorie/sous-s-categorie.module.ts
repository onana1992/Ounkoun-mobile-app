import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SousSCategoriePage } from './sous-s-categorie';

@NgModule({
  declarations: [
   // SousSCategoriePage,
  ],
  imports: [
    IonicPageModule.forChild(SousSCategoriePage),
  ],
})
export class SousSCategoriePageModule {}
