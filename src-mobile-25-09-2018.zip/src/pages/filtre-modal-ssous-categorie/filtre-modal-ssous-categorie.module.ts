import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FiltreModalSsousCategoriePage } from './filtre-modal-ssous-categorie';

@NgModule({
  declarations: [
   // FiltreModalSsousCategoriePage,
  ],
  imports: [
   // IonicPageModule.forChild(FiltreModalSsousCategoriePage),
  ],
})
export class FiltreModalSsousCategoriePageModule {}
