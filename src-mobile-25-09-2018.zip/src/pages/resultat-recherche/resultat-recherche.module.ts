import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResultatRecherchePage } from './resultat-recherche';

@NgModule({
  declarations: [
    //ResultatRecherchePage,
  ],
  imports: [
    //IonicPageModule.forChild(ResultatRecherchePage),
  ],
})
export class ResultatRecherchePageModule {}
