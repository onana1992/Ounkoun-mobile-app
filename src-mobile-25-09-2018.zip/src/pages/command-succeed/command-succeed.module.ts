import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CommandSucceedPage } from './command-succeed';

@NgModule({
  declarations: [
   // CommandSucceedPage,
  ],
  imports: [
   // IonicPageModule.forChild(CommandSucceedPage),
  ],
})
export class CommandSucceedPageModule {}
