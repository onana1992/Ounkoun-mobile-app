import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PanierBwmPage } from './panier-bwm';

@NgModule({
  declarations: [
   // PanierBwmPage,
  ],
  imports: [
    IonicPageModule.forChild(PanierBwmPage),
  ],
})
export class PanierBwmPageModule {}
