import { Component ,ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams,ModalController,AlertController,Content } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { ProduitPage} from '../produit/produit';
import { Storage } from '@ionic/storage';
import { FavorisPage } from '../favoris/favoris';
import { HomePage } from '../home/home';
import { RecherchePage } from '../recherche/recherche';
import { FiltreModalCatPage } from '../filtre-modal-cat/filtre-modal-cat';
import { FitreModalSouscatPage } from  '../fitre-modal-souscat/fitre-modal-souscat';



@IonicPage()
@Component({
  selector: 'page-sous-categorie',
  templateUrl: 'sous-categorie.html',
})
export class SousCategoriePage {
	
	view:String = "view1";
	categorieName:any;
	filterOption= "filter-by-popularity";
	filterMarque="null";
	filterMinPrice="null";
	filterMaxPrice= "null";
	filterLabel= "Popularité";
	baseUrl = 'http://node16375-ounkoun1.hidora.com/backend/web/app_dev.php/';
	sousCategorieName:any;
	page=1;
	response:any;
	produits:any;
	categorie:any;
	nbProduits:number;
	isLoading = true;
	favoryArray= new Array();
	panierArray= new Array();
	localFavoryArray= new Array();
	showMessageAjoutFavori:boolean=false;
	showMessageAjoutPanier:boolean=false;
	favorisData={login:"",idProduct:""};
	panierData={login:"",idProduct:"",type:"detail",number:1};
	login="";
	isConnected:boolean=false;
	isFilterActivated:boolean=false;
	panierSize:number=0;
	favorisSize:number=0;
	@ViewChild(Content) content: Content;
	

  constructor(public navCtrl: NavController, public navParams: NavParams,private restProvider: RestProvider,
	public modalCtrl : ModalController,public alertCtrl: AlertController,private storage: Storage) {
	 
		this.sousCategorieName = navParams.get('nomSousCategorie');
		this.categorieName = navParams.get('nomCategorie');
		this.restProvider.setView1();
		this.storage.get('user').then((val) => {
				this.isConnected= (val == null)? false:true;
				if(this.isConnected){
					this.login= val.login;
				}
		});
		
		this.restProvider.getProduitPerSousCat(this.sousCategorieName,this.page,this.filterOption,this.filterMinPrice,this.filterMaxPrice,this.filterMarque).subscribe(
			
			data => {
				this.response = data.data;
				this.produits = data.data.products;
				this.nbProduits= data.data.size;
				this.isLoading = false;
				console.log(data);
			},
			err => {
				console.log(err);
			},
			() => console.log('Complete')
		);
		
		
		
		this.storage.get('panier').then((val) => {	
			if(val!= undefined ){
				this.panierSize=0;
				for(var i=0;i<val.length;i++){
					this.panierSize+= val[i].number;
				}
			}
		});	
		
		this.storage.get('favoris').then((val) => {	
			if(val!= undefined ){
				this.favorisSize= val.length;

			}
		});	
	 
    }

	ionViewDidLoad() {
		console.log('ionViewDidLoad CategoriePage');
	}
  
  
	scrollToTop() {
		// Scrolls to the top, ie 0px to top.
		this.content.scrollToTop();
	}
  
  cancelFilter(){
	    
	this.filterMinPrice="null";
	this.filterMaxPrice="null";
	this.filterMarque="null";
	this.isLoading= true;
	
	this.restProvider.getProduitPerSousCat(this.sousCategorieName,this.page,this.filterOption,this.filterMinPrice,this.filterMaxPrice,this.filterMarque).subscribe(
        data => {
            this.response = data.data;
			this.produits = data.data.products;
			this.nbProduits= data.data.size;
			this.isLoading = false;
			this.isFilterActivated= false;
            console.log(data);
        },
        err => {
            console.log(err);
        },
        () => console.log('Complete')
	   );
			
    }
  
    showFiltreModal(){
		
		let myModal = this.modalCtrl.create(FitreModalSouscatPage, {categorie:this.categorieName, sousCat: this.sousCategorieName});
		myModal.present();
		myModal.onDidDismiss((data) => {
			if(data != undefined ){
				
				if(data.filter == "marque"){
					this.filterMarque= data.marque;
					this.isLoading = true;
					this.isFilterActivated= true;
					this.restProvider.getProduitPerSousCat(this.sousCategorieName,this.page,this.filterOption,this.filterMinPrice,this.filterMaxPrice,this.filterMarque).subscribe(
					data => {
						this.response = data.data;
						this.produits = data.data.products;
						this.nbProduits= data.data.size;
						this.isLoading = false;
						console.log(data);
					},
						err => {
							console.log(err);
						},
						() => console.log('Complete')
					);
				}
				
				else if(data.filter == "prix"){
					this.isLoading= true;
					this.filterMinPrice = data.valeur.lower;
					this.filterMaxPrice = data.valeur.upper;
					this.isFilterActivated= true;
					this.restProvider.getProduitPerSousCat(this.sousCategorieName,this.page,this.filterOption,this.filterMinPrice,this.filterMaxPrice,this.filterMarque).subscribe(
					data => {
						this.response = data.data;
						this.produits = data.data.products;
						this.nbProduits= data.data.size;
						this.isLoading = false;
						console.log(data);
					},
						err => {
							console.log(err);
						},
						() => console.log('Complete')
					);
				}
			}
			
		});
	}
	
  
	changeView(view){
		
		if (view === "view1") {
			this.view="view2"
		} 
		else if (view === 'view2') {
			this.view="view3";
		}
		
		else if (view === "view3") {
			this.view="view1";
		}
	}
  
 
	showTriChoix(){
		
		let alert = this.alertCtrl.create();
		alert.setTitle('Trier par:');
			 alert.addInput(   
			{
				type: 'radio',
				label: 'popularité',
				value: 'filter-by-popularity',
				checked: this.filterOption == 'filter-by-popularity'? true:false,
			}
	    );
	
		alert.addInput(
			{
				type: 'radio',
				label: 'plus rescent',
				value: 'filter-by-most-rescent',
				checked: this.filterOption == 'filter-by-most-rescent'? true:false,
			}
	    );
	
		alert.addInput(
			{
				type: 'radio',
				label: 'prix decroissant',
				value: 'filter-by-price-desc',
				checked: this.filterOption == 'filter-by-price-desc'? true:false,
				
			}
		);
	
		alert.addInput(
			{
				type: 'radio',
				label: 'prix croisant',
				value: 'filter-by-price-asc',
				checked: this.filterOption == 'fliter-by-price-asc'? true:false,
			}
		);

		alert.addButton('Cancel');
		alert.addButton({
			text: 'OK',
			handler: data => {
			//this.testRadioOpen = false;
			//this.testRadioResult = data;
			this.filterOption=data;
			if(this.filterOption=="filter-by-most-rescent"){
				this.filterLabel="Plus rescent";
			}
			else if(this.filterOption=="filter-by-price-desc"){
				this.filterLabel="Prix desc.";
			}
			else if(this.filterOption=="filter-by-price-asc"){
				this.filterLabel="Prix asc.";
			}
		
			console.log('Radio data:', data);
			this.isLoading = true;
			this.restProvider.getProduitPerSousCat(this.sousCategorieName ,this.page,data,this.filterMinPrice,this.filterMaxPrice,this.filterMarque).subscribe(
			data => {
				this.response = data.data;
				this.produits = data.data.products;
				this.isLoading = false;
				console.log(data);
			},
			err => {
				console.log(err);
			},
			() => console.log('Complete')
		   );
		   
		  }
		});
		alert.present();
  }
  
  
  showPageChoix(){
	var modulo = 0;
	var nbPage = 0;
	 
    let alert = this.alertCtrl.create();
    alert.setTitle('Aller a la page:');
	
	modulo = this.nbProduits % 15;
	nbPage= (modulo==0)? (this.nbProduits/15) : Math.ceil(this.nbProduits/15);

	for(var i=0; i<nbPage; i++){
		alert.addInput(
			{
				type: 'radio',
				label: ''+(i+1)+'',
				value: (i+1).toString(),
				checked: (this.page== i+1)? true:false,
			}
		);
	}
    alert.addButton('Cancel');
    alert.addButton({
      text: 'OK',
      handler: data => {
		  this.page=data;
		console.log('Radio data:', data);
		this.isLoading = true;
		this.restProvider.getProduitPerSousCat(this.sousCategorieName ,this.page,this.filterOption,this.filterMinPrice,this.filterMaxPrice,this.filterMarque).subscribe(
        data => {
            this.response = data.data;
			this.produits = data.data.products;
			this.isLoading = false;
            console.log(data);
        },
        err => {
            console.log(err);
        },
        () => console.log('Complete')
	   );
	   
      } 
    });
    alert.present();
  }
  
  goSuivant(){
	var modulo=0;
	var nbPage=0;
	modulo = this.nbProduits % 15;
	nbPage = (modulo==0)? (this.nbProduits/15) : Math.ceil(this.nbProduits/15);
	if(nbPage > this.page){
		this.isLoading = true;
		this.page++;
		this.restProvider.getProduitPerSousCat(this.sousCategorieName ,this.page,this.filterOption,this.filterMinPrice,this.filterMaxPrice,this.filterMarque).subscribe(
		data => {
			this.response = data.data;
			this.produits = data.data.products;
			this.isLoading = false;
			console.log(data);
		},
		err => {
            console.log(err);
		},
		() => console.log('Complete'));	
	}
	  
  } 
  
  goPrecedant(){
	if(this.page > 1){
		this.isLoading = true;
		this.page--;
		this.restProvider.getProduitPerSousCat(this.sousCategorieName,this.page,this.filterOption,this.filterMinPrice,this.filterMaxPrice,this.filterMarque).subscribe(
		data => {
			this.response = data.data;
			this.produits = data.data.products;
			this.isLoading = false;
			console.log(data);
		},
		err => {
            console.log(err);
		},
		() => console.log('Complete'));	
	}
	  
  } 
   
   gotoProduct(productName){
	this.navCtrl.push(ProduitPage, {ProduitName: productName});  
   }
  
   objecttoParams(obj) {
		var p = [];
		for (var key in obj) {
		p.push(key + '=' + encodeURIComponent(obj[key]));
		}
		return p.join('&');
   }
  
    addFavorite(produit:any, event: Event){
		event.stopPropagation(); //THIS DOES THE MAGIC
		if(this.isConnected){
			 this.storage.get('favoris').then((val) => {
				if(val!=null){
					this.localFavoryArray= val;
					for(var i=0; i< val.length;i++){
						if(produit.name == val[i].name){
							return;
						}
					}
					this.localFavoryArray.push({name:produit.name});
					this.storage.set("favoris",this.localFavoryArray);
					this.showMessageAjoutFavori=true;
					this.favorisSize +=1;
					setTimeout(() => {
						this.showMessageAjoutFavori=false;
					}, 2000);
					this.favorisData.login= this.login;
					this.favorisData.idProduct= produit.id;
					this.restProvider.postFavori(this.objecttoParams(this.favorisData)).subscribe(
						data => {
						},
						err => {
							console.log(err);
						},
					() => console.log('Complete'));
				
				}else{
					this.localFavoryArray.push({name:produit});
					this.storage.set("favoris",this.localFavoryArray);
					this.favorisSize +=1;
				}
					
			});
		}
		else{
			alert("pas connecter");
		}
	}
  
	addPanier(produit:any, event: Event){ 
		event.stopPropagation(); //THIS DOES THE MAGIC
		var number=0;
		this.storage.get('panier').then((val) => {
			
			if(val!=null){
				this.panierArray=val;
			}
			
			 
			for(var i=0;i< this.panierArray.length;i++){
				if(this.panierArray[i].productId == produit.id && this.panierArray[i].type=="detail" ){
				 number= this.panierArray[i].number;
				 this.panierArray.splice(i,1);
				}
				
			} 
			
			if(number+1<=produit.quantity){
				this.panierArray.push({productId:produit.id,name:produit.name,number:number+1,type:"detail",product:produit});
				this.storage.set("panier",this.panierArray);
				this.showMessageAjoutPanier=true;
				this.panierSize+=1;
				setTimeout(() => {
						this.showMessageAjoutPanier=false;
				}, 2000);
				if(this.isConnected){
					this.panierData.login= this.login;
					this.panierData.idProduct= produit.id;
					this.restProvider.postPanier(this.objecttoParams(this.panierData)).subscribe(
							data => {
								
							},
							err => {
								console.log(err);
							},
					() => console.log('Complete'));
				}
			}
			else{
				
			} 
		});
	}

	openPanier(){ 
		this.navCtrl.popToRoot();
		this.restProvider.setView3();
    }
  

	goTorecheche(){
		this.navCtrl.push(RecherchePage);
	}

	openFavoris(){
		  if(this.isConnected){
			this.navCtrl.push(FavorisPage);
		  }
		  else{
			this.navCtrl.push(HomePage,{ page :"tab2" });   
		  }
		  
	 }
   
 
}


