import { Component,ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams,ModalController,AlertController,Content  } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import {ProduitPage} from '../produit/produit';
//import {HomePage} from '../home/home';
import { Storage } from '@ionic/storage';
import { FavorisPage } from '../favoris/favoris';

@IonicPage()
@Component({
  selector: 'page-produit-par-marque',
  templateUrl: 'produit-par-marque.html',
})
export class ProduitParMarquePage {
	
	view:String = "view1";
	categorieName:any;
	filterOption= "filter-by-popularity";
	filterLabel= "Popularité";
	page=1;
	response:any;
	produits:any;
	categorie:any;
	marqueName:any
	nbProduits:number;
	isLoading = true;
	favoryArray= new Array();
	panierArray= new Array();
	localFavoryArray= new Array();
	showMessageAjoutFavori:boolean=false;
	showMessageAjoutPanier:boolean=false;
	favorisData={login:"",idProduct:""};
	panierData={login:"",idProduct:"",type:"detail",number:1};
	login="";
	panierSize:number=0;
	favorisSize:number=0;
	isConnected:boolean=false;
	baseUrl = 'http://node16375-ounkoun1.hidora.com/backend/web/app_dev.php/';
	@ViewChild(Content) content: Content;
	

    constructor(public navCtrl: NavController, public navParams: NavParams,private restProvider: RestProvider,
     public modalCtrl : ModalController,public alertCtrl: AlertController,private storage: Storage) {
	 
	 this.restProvider.setView1();
	this.marqueName = navParams.get('nomMarque'); 
	
	this.storage.get('user').then((val) => {
			this.isConnected= (val == undefined)? false:true;
			if(this.isConnected){
				this.login= val.login;
			}
	});
	
	this.storage.get('panier').then((val) => {	
		if(val!= undefined ){
			this.panierSize=0;
			for(var i=0;i<val.length;i++){
				this.panierSize+= val[i].number;
			}
		}
	});	
	
	
	this.storage.get('favoris').then((val) => {	
		if(val!= undefined ){
			this.favorisSize= val.length;

		}
	});	
		
	
	this.restProvider.getProduitPerMarque(this.marqueName,this.page,this.filterOption).subscribe(
        data => {
            this.response = data.data;
			this.produits = data.data.products;
			this.nbProduits= data.data.size;
			this.isLoading = false;
            console.log(data);
        },
        err => {
            console.log(err);
        },
        () => console.log('Complete')
	);
	 
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CategoriePage');
  }
  
  scrollToTop() {
		// Scrolls to the top, ie 0px to top.
		this.content.scrollToTop();
  }
  
  
  
  changeView(view){
	  if (view === "view1") {
		this.view="view2"
	} 
	else if (view === 'view2') {
		this.view="view3";
	}
	
	else if (view === "view3") {
		this.view="view1";
	}
  }
  
 
  showTriChoix(){
    let alert = this.alertCtrl.create();
    alert.setTitle('Trier par:');
	
	alert.setTitle('Trier par:');
			 alert.addInput(   
			{
				type: 'radio',
				label: 'popularité',
				value: 'filter-by-popularity',
				checked: this.filterOption == 'filter-by-popularity'? true:false,
			}
	);

    alert.addInput(
		{
			type: 'radio',
			label: 'plus rescent',
			value: 'filter-by-most-rescent',
			checked: this.filterOption == 'filter-by-most-rescent'? true:false,
		}
	);
	
	alert.addInput(
		{
			type: 'radio',
			label: 'prix decroissant',
			value: 'filter-by-price-desc',
			checked: this.filterOption == 'filter-by-price-desc'? true:false,
			
		}
	);
	
	alert.addInput(
		{
			type: 'radio',
			label: 'prix croisant',
			value: 'filter-by-price-asc',
			checked: this.filterOption == 'fliter-by-price-asc'? true:false,
			
		
		}
	);

    alert.addButton('Cancel');
    alert.addButton({
      text: 'OK',
      handler: data => {
 
		this.filterOption=data;
		if(this.filterOption=="filter-by-most-rescent"){
			this.filterLabel="Plus rescent";
		}
		else if(this.filterOption=="filter-by-price-desc"){
			this.filterLabel="Prix desc.";
		}
		else if(this.filterOption=="filter-by-price-asc"){
			this.filterLabel="Prix asc.";
		}
		
		console.log('Radio data:', data);
		this.isLoading = true;
		this.restProvider.getProduitPerMarque(this.marqueName,this.page,data).subscribe(
        data => {
            this.response = data.data;
			this.produits = data.data.products;
			this.isLoading = false;
            console.log(data);
        },
        err => {
            console.log(err);
        },
        () => console.log('Complete')
	   );
	   
      }
    });
    alert.present();
  }
  
  
  showPageChoix(){
	var modulo = 0;
	var nbPage = 0;
	 
    let alert = this.alertCtrl.create();
    alert.setTitle('Aller a la page:');
	
	modulo = this.nbProduits % 15;
	nbPage= (modulo==0)? (this.nbProduits/15) : Math.ceil(this.nbProduits/15);

	for(var i=0; i<nbPage; i++){
		alert.addInput(
			{
				type: 'radio',
				label: ''+(i+1)+'',
				value: (i+1).toString(),
				checked: (this.page== i+1)? true:false,
			}
		);
	}
    alert.addButton('Cancel');
    alert.addButton({
      text: 'OK',
      handler: data => {
		  this.page=data;
		console.log('Radio data:', data);
		this.isLoading = true;
		this.restProvider.getProduitPerMarque(this.marqueName,this.page,this.filterOption).subscribe(
        data => {
            this.response = data.data;
			this.produits = data.data.products;
			this.isLoading = false;
            console.log(data);
        },
        err => {
            console.log(err);
        },
        () => console.log('Complete')
	   );
	   
      } 
    });
    alert.present();
  }
  
  goSuivant(){
	var modulo=0;
	var nbPage=0;
	modulo = this.nbProduits % 15;
	nbPage = (modulo==0)? (this.nbProduits/15) : Math.ceil(this.nbProduits/15);
	if(nbPage > this.page){
		this.isLoading = true;
		this.page++;
		this.restProvider.getProduitPerMarque(this.marqueName,this.page,this.filterOption).subscribe(
		data => {
			this.response = data.data;
			this.produits = data.data.products;
			this.isLoading = false;
			console.log(data);
		},
		err => {
            console.log(err);
		},
		() => console.log('Complete'));	
	}
	  
  } 
  
  goPrecedant(){
	if(this.page > 1){
		this.isLoading = true;
		this.page--;
		this.restProvider.getProduitPerMarque(this.marqueName,this.page,this.filterOption).subscribe(
		data => {
			this.response = data.data;
			this.produits = data.data.products;
			this.isLoading = false;
			console.log(data);
		},
		err => {
            console.log(err);
		},
		() => console.log('Complete'));	
	}  
  } 
  
  gotoProduct(productName){
	this.navCtrl.push(ProduitPage, {ProduitName: productName});  
  }
  
  objecttoParams(obj) {
		var p = [];
		for (var key in obj) {
		p.push(key + '=' + encodeURIComponent(obj[key]));
		}
		return p.join('&');
  }
  
    addFavorite(produit:any, event: Event){
	event.stopPropagation(); //THIS DOES THE MAGIC
	if(this.isConnected){
		 this.storage.get('favoris').then((val) => {
			if(val!=null){
				this.localFavoryArray= val;
				for(var i=0; i< val.length;i++){
					if(produit.name == val[i].name){
						return;
					}
				}
				this.localFavoryArray.push({name:produit.name});
				this.storage.set("favoris",this.localFavoryArray);
				this.showMessageAjoutFavori=true;
				this.favorisSize +=1;
				setTimeout(() => {
					this.showMessageAjoutFavori=false;
				}, 2000);
				this.favorisData.login= this.login;
				this.favorisData.idProduct= produit.id;
				this.restProvider.postFavori(this.objecttoParams(this.favorisData)).subscribe(
					data => {
					},
					err => {
						console.log(err);
					},
				() => console.log('Complete'));
			
			}else{
				this.localFavoryArray.push({name:produit});
				this.storage.set("favoris",this.localFavoryArray);
				this.favorisSize+=1;
			}
				
		});
	}
	else{
		alert("pas connecter");
	}
	
  }
  
  addPanier(produit:any, event: Event){ 
	event.stopPropagation(); //THIS DOES THE MAGIC
	var number=0;
	this.storage.get('panier').then((val) => {
		
		if(val!=null){
			this.panierArray=val;	
		}
		
		 
		for(var i=0;i< this.panierArray.length;i++){
			if(this.panierArray[i].productId == produit.id && this.panierArray[i].type=="detail" ){
			 number= this.panierArray[i].number;
			 this.panierArray.splice(i,1);
			}
		} 
		
		if(number+1<=produit.quantity){
			
			this.panierArray.push({productId:produit.id,name:produit.name,number:number+1,type:"detail",product:produit});
			this.storage.set("panier",this.panierArray);
			this.panierSize+=1;
			this.showMessageAjoutPanier=true;
			setTimeout(() => {
					this.showMessageAjoutPanier=false;
			}, 2000);
			if(this.isConnected){
				this.panierData.login= this.login;
				this.panierData.idProduct= produit.id;
				this.restProvider.postPanier(this.objecttoParams(this.panierData)).subscribe(
						data => {
							
						},
						err => {
							console.log(err);
						},
				() => console.log('Complete'));
			}
		}
		else{
			
		} 
		
	});  
  }
  
  openPanier(){ 
	this.navCtrl.popToRoot();
	this.restProvider.setView3();
  }
  
  openFavoris(){
	this.navCtrl.push(FavorisPage);  
  }
   
}
