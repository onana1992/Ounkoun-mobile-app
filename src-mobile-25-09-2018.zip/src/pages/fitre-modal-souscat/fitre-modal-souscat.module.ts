import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FitreModalSouscatPage } from './fitre-modal-souscat';

@NgModule({
  declarations: [
   // FitreModalSouscatPage,
  ],
  imports: [
   // IonicPageModule.forChild(FitreModalSouscatPage),
  ],
})
export class FitreModalSouscatPageModule {}
