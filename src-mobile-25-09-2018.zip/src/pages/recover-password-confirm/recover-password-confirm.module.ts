import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RecoverPasswordConfirmPage } from './recover-password-confirm';

@NgModule({
  declarations: [
   // RecoverPasswordConfirmPage,
  ],
  imports: [
   // IonicPageModule.forChild(RecoverPasswordConfirmPage),
  ],
})
export class RecoverPasswordConfirmPageModule {}
