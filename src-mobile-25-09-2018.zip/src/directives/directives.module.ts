import { NgModule } from '@angular/core';
@NgModule({
	declarations: [
	//HideFabDirective,
    //AutoHideDirective
	],
	imports: [],
	exports: [
	//HideFabDirective,
   // AutoHideDirective
	]
})
export class DirectivesModule {}
